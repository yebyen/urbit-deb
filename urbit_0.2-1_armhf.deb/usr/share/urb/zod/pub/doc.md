urbit
=====

is a general-purpose computing stack designed to live in the cloud. 

<list dataPreview="true"></list>

`arvo` is event driven and modular. `arvo` modules are called 'vanes'.

<list dataPath="/pub/doc/arvo" dataPreview="true"></list>

------------------------------------------------------------------------

If you're new to the system, take a look at some of the
[guides](doc/guide) to get oriented. Come join us on `:talk` in the
`/urbit-meta` channel to ask questions and get help.
