[wutpaz, %wtpz](#wtpz)
======================

[`++tiki`]() version of [`%wtpt`]()

`wutpaz` is used internally.

Produces
--------

Twig: `[%wtpz p=tiki q=twig r=twig]`

Sample
------

`p` is a [`++tiki`](). `q` and `r` are [twig]()s.

Tall form
---------

None

Wide form
---------

None

Irregular form
--------------

None

Examples
--------
