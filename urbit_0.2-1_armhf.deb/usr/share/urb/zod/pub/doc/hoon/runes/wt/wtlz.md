[wutlaz, %wtlz](#wtlz)
======================

[`++tiki`]() version of [`%wtls`]()

`wutlaz` is a synthetic rune that selects a case in `q` for the actual
type of `p`. Only used internally.

Produces
--------

Twig: `[%wtlz p=wing q=twig r=tine]`

Sample
------

`p` is a [`++wing`](). `q` is a [twig](). `r` is a [`++tine`]().

Tall form
---------

None

Wide form
---------

None

Irregular form
--------------

None

Examples
--------
