wuttaz, `?=`, %wttz
============================

[`++tiki`]() version of [`%wtkz`]()

`wuttaz` is only used internally.

Produces
--------

Twig: `[%wttz p=tile q=tiki]`

Sample
------

`p` is a [tile](). `q` is a [`++tiki`]().

Tall form
---------

    ?=  p
        q

Wide form
---------

    ?=(p q)

Irregular form
--------------

None

Examples
--------
