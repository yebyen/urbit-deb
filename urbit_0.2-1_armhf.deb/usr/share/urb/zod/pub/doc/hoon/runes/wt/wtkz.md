wutkaz, %wtkz
======================

[`++tiki`]() version of [`%wtkt`]()

`wutkaz` is only used internally.

Produces
--------

Twig: `[%wtkz p=tiki q=twig r=twig]`

Sample
------

`p` is a [`++tiki`](). `q` and `r` are [twig]()s.

Tall form
---------

None

Wide form
---------

None

Irregular form
--------------

None

Examples
--------
