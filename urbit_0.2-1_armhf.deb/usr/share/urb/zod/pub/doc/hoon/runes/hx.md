<div class="short">

`hax # $ %hax`
============

Pretty printing
---------------

The `#` runes are used for pretty printing. They are both synthetic.

</div>

[`#<`]() pretty prints one or more values to a [`++tape`]().

[`#>`]() pretty prints one or more values to a [`++tank`]().

<hr></hr>

<kids></kids>