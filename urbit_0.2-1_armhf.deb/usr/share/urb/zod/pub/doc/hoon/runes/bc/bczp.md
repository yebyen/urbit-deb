[buczap `$!` %bczp](#bczp)
==========================

Axil bunt

`$!` is an synthetic internal twig that produces the [bunt]() (default
value) for `[%axil p]`.

Produces
--------

[Twig](): `[%bczp p=base]`

Sample
------

`p` is a [base]() [axil]() type.

Tall form
---------

None

Wide form
---------

None

Irregular form
--------------

None

Examples
--------

    ~zod/try=> (ream '~')
    [%bczp p=%null]
    ~zod/try=> (make '~')
    [%1 p=0]
