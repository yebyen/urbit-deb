<div class="short">

`%arvo`
=======

Our operating system.

</div>
