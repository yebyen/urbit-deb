`%arvo` commentary
==================

`%arvo` is our operating system.
