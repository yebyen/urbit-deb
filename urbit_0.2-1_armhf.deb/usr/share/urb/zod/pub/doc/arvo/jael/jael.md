Jael: Reference
===============

Jael: Commentary
================
