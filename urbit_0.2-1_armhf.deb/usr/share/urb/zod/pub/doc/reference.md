<div class="short">

References
==========

These references cover terminology and our interpreter, `vere`.

</div>

------------------------------------------------------------------------

<list></list>
