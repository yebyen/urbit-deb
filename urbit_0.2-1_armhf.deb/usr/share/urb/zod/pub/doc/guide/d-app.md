A fully featured app using %ford and %gall
