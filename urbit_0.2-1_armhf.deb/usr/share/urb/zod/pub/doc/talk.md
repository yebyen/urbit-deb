<div class="short">

talk
====

talk is our messaging application.

talk is in dire need of better documentation

</div>

------------------------------------------------------------------------

This document should include <a href="./talk/help">the command reference</a> somehow.
