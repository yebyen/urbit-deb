<div class="short">

hoon
====

hoon is our programming language.

hoon is a strict, typed, functional language that compiles itself to
nock. The hoon compiler is 4000 lines of hoon. Adding standard
libraries, the self-compiling kernel is 8000 lines. The hoon compiler is
located towards the bottom of `/=main=/arvo/hoon.hoon`. The standard
library is split between `/=main=/arvo/hoon.hoon` and
`/=main=/arvo/zuse.hoon`.

hoon has no particular familial relationship to other languages you may
know. It uses its own type inference algorithm and is as different from
Haskell as from Lisp. hoon syntax is also completely unfamiliar. hoon
uses ascii digraphs, which we call 'runes', instead of reserved words.

</div>

------------------------------------------------------------------------

<list></list>
