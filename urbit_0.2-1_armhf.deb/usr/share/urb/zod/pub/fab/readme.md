/=main=/pub/fab/

This directory is intended to hold your `%ford` core files.