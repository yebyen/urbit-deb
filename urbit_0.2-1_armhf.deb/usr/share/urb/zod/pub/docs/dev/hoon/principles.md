---
logo: black
sort: 2
title: Hoon 101
---

Welcome to Hoon 101!

Ideally, you've installed an Urbit planet (if you have a ticket)
or comet (if you don't).  See the [user doc](../../user).  We
recommend opening up the dojo and just typing the examples; you
don't know a language until you know it in your fingers.

Hoon 101 is still under construction; new chapters are posted
roughly once a week.  So far:

<list></list>

