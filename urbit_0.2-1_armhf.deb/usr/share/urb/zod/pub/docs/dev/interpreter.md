---
hide: true
logo: black
sort: 5
title: Interpreter
---

# Interpreter

The Urbit interpreter is written in C. 

Watch this space for actual documentation.
