---
layout: video
sort: 3
title: demo.2013
---

# demo.2013

<iframe src="https://player.vimeo.com/video/75312418?color=fff&amp;title=0&amp;byline=0&amp;portrait=0" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>

## DVD commentary

<div class='short'>

#### CY
This is what Urbit looked like two years ago.  Yes, we can still do all this stuff.  But...

Urbit in 2013 had the same Nock and pretty much the same Hoon, but Arvo was a prototype.  For instance: you'll see a shell and a messenger in this video.  The shell is built into the kernel, and so is the talk protocol.  We've learned a lot about purely functional operating systems since then...

</div>

