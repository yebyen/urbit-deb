# installing

`npm install`

# building

in `src/js/`:
`watchify -v -t coffeeify -o main.js main.coffee`

in `src/css/`:
`stylus -w main.styl`

